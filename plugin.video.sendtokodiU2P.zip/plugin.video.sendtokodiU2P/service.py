# -*- coding: utf-8 -*-
import json
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
try:
    # Python 3
    from urllib.parse import unquote
    unichr = chr
except ImportError:
    # Python 2
    from urllib import unquote


class replacement_stderr(sys.stderr.__class__):
    def isatty(self): return False

sys.stderr.__class__ = replacement_stderr

def debug(content):
    log(content, xbmc.LOGDEBUG)


def notice(content):
    log(content, xbmc.LOGNOTICE)


def log(msg, level=xbmc.LOGNOTICE):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def linkDownloadUptobox(key, fileCode):
    # lien de download
    url1 = "https://uptobox.com/api/link?token=%s&file_code=%s" % (key, fileCode)
    try:
        req = requests.get(url1)
        dict_liens = req.json()
        dlLink = dict_liens["data"]["dlLink"]
    except Exception as e:
        print(e)
        dlLink = ""
        
    return dlLink, dict_liens["statusCode"] 

def linkDownload1Fichier(key, linkUrl): 
    params = {
            'url' : linkUrl,
            'inline' : 0,
            'cdn' : 0,
            'restrict_ip':  0,
            'no_ssl' : 0,
            }
    url = 'https://api.1fichier.com/v1/download/get_token.cgi'
    r = requests.post(url, json=params, headers={'Authorization':'Bearer {}'.format(key),'Content-Type':'application/json'})
    try:
        o = r.json()
    except JSONDecodeError:
        pass
    message = ""
    url = ""
    if 'status' in o:
        if o['status'] != 'OK':
            message = r.json()['message']
            o['url'] = ""
        return o["url"], message
    
    else:
        #key out => No such user
        return url, message


def showInfoNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message, xbmcgui.NOTIFICATION_INFO, 5000)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)


# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])

def getkeyUpto():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("keyupto")
    #notice("apikey Upto: %s" %Apikey)

    if not Apikey:
        dialog = xbmcgui.Dialog()
        d = dialog.input("ApiKey UptoBox: ", type=xbmcgui.INPUT_ALPHANUM)
        notice(d)
        addon.setSetting(id="keyupto", value=d)
        key = d
    else:
        key = Apikey
    return key

def getkey1fichier():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("key1fichier")
    #notice("apikey 1fichier: %s" %Apikey)

    if not Apikey:
        dialog = xbmcgui.Dialog()
        d = dialog.input("ApiKey 1fichier: ", type=xbmcgui.INPUT_ALPHANUM)
        notice(d)
        addon.setSetting(id="key1fichier", value=d)
        key = d
    else:
        key = Apikey
    return key


def getParams():
    result = {}
    paramstring = sys.argv[2]
    paramstring = paramstring.split("*")
    if len(paramstring) == 1:
        result['url'] = paramstring[0]
    else:
        dialog = xbmcgui.Dialog()
        tabNomLien = ["Lien N° %d (ind)" %(i + 1) for i, x in enumerate(paramstring)]
        selected = dialog.select("Choix lien", tabNomLien)
        notice(selected)
        if selected != -1:
            result['url'] = paramstring[selected]
        else:
            result['url'] = ""
        
    if "uptobox" in result['url']:
        filecode = result['url'].split("/")[-1].strip()
        urlDedrid, status = linkDownloadUptobox(getkeyUpto(), filecode)
        result['url'] = urlDedrid.strip()
        if status == 16:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="keyupto", value="")
    elif "1fichier" in result['url']:
        result['url'] = result['url'].strip()
        result['url'] = result['url'].replace("?http", "http") 
        notice("Url 1fichier: %s" %result['url'])
        urlDedrid, status = linkDownload1Fichier(getkey1fichier(), result['url'].strip())
        result['url'] = urlDedrid.strip()
        notice("status: %s" %status)
        if "No such user" in status or "Not authenticated" in status:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="key1fichier", value="")
    if result['url'][:-4] in [".mkv", ".mp4"]:
        title = unquote(result['url'][:-4].split("/")[-1])#, encoding='latin-1', errors='replace')
    else:
        title = unquote(result['url'].split("/")[-1])#, encoding='latin-1', errors='replace')
    
    result["title"] = title
    notice(result)
    return result


def createListItemFromVideo(video):
    notice(video)
    url = video['url']
    #thumbnail = video.get('thumbnail')
    title = video['title']
    notice(url)
    list_item = xbmcgui.ListItem(title, path=url)
    list_item.setInfo(type='Video', infoLabels={'Title': title})

    #if thumbnail is not None:
    #    list_item.setArt({'thumb': thumbnail})

    return list_item


result = getParams()
url = str(result['url'])
# Just a video, pass the item to the Kodi player.
if result['url']:
    showInfoNotification("playing title " + result['title'])
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=createListItemFromVideo(result))
